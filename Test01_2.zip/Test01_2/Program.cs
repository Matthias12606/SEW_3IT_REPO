﻿// See https://aka.ms/new-console-template for more information
using Test01_2;

QuadraticEquation test = new QuadraticEquation();

test.SolveReal(2, 16, 14);
test.SolveReal(1.1, 2.1, 3.1);
